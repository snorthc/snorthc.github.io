// Runs beside the page. Carries the page's requests to the extension's background and the answers back, and shows
// Astrala's own warnings on the page itself, because that is where you are looking when a site tries something.

/** A bar across the top of the page, in its own shadow root so the page can neither restyle nor read it. Text only. */
function warn(title, text) {
  document.getElementById('astrala-guard')?.remove()
  const host = document.createElement('div')
  host.id = 'astrala-guard'
  const root = host.attachShadow({ mode: 'closed' })
  const css = document.createElement('style')
  css.textContent = `:host { all: initial; position: fixed; top: 12px; left: 50%; transform: translateX(-50%); z-index: 2147483647; width: min(560px, calc(100vw - 24px)); }
    div { display: flex; gap: 12px; align-items: flex-start; padding: 14px 16px; border-radius: 16px; background: #1a0d0e; color: #f2ede6; box-shadow: 0 0 0 1px rgba(236, 106, 106, .55), 0 18px 50px -12px rgba(0, 0, 0, .8); font: 14px/1.45 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; }
    b { display: block; color: #ffb9b9; margin-bottom: 2px; } p { margin: 0; flex: 1; }
    button { font: inherit; font-weight: 600; color: #f2ede6; background: rgba(255, 255, 255, .12); border: 0; border-radius: 99px; height: 30px; padding: 0 14px; cursor: pointer; flex-shrink: 0; }`
  const box = document.createElement('div'), p = document.createElement('p'), b = document.createElement('b'), close = document.createElement('button')
  b.textContent = title
  p.append(b, document.createTextNode(text))
  close.textContent = 'Dismiss'
  close.addEventListener('click', () => host.remove())
  box.append(p, close)
  root.append(css, box)
  ;(document.body || document.documentElement).append(host)
}

window.addEventListener('message', (e) => {
  const m = e.data
  if (e.source !== window || !m || m.to !== 'astrala-content' || typeof m.method !== 'string') return
  const back = (r) => {
    // the Drain guard refused it: the site only shows its own error, so say why here
    if (r && r.error && /Drain guard blocked/.test(r.error.message || '')) warn('Astrala blocked a request from this site', String(r.error.message).replace(/^Astrala's Drain guard blocked this (request|site): /, 'Reason: '))
    window.postMessage({ to: 'astrala-inpage', id: m.id, ...r }, '*')
  }
  try {
    chrome.runtime.sendMessage({ type: 'rpc', method: m.method, params: m.params }).then(
      (r) => back(r || { error: { code: 4900, message: "Astrala didn't answer" } }),
      () => back({ error: { code: 4900, message: 'The Astrala extension was restarted. Refresh this page.' } }))
  } catch { back({ error: { code: 4900, message: 'The Astrala extension was restarted. Refresh this page.' } }) }
})

// Once per page (not per frame): if this address is dressed up as a well-known site, say so before anything is clicked.
if (window === window.top) {
  const check = () => { try { chrome.runtime.sendMessage({ type: 'check' }).then((r) => { if (r && r.imitates) warn(`This is not ${r.imitates}`, `This site's address imitates ${r.imitates}. Sites like this exist to empty wallets.${r.guard ? ' Astrala will not connect to it.' : ' Your Drain guard is off, so Astrala would let you connect: do not.'}`) }, () => {}) } catch { /* extension reloaded */ } }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', check, { once: true }); else check()
}
