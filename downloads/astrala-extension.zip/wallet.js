// The gate in front of the wallet. The wallet itself is extension/app (the Astrala app's own screens); this small page
// only handles the two things that must come first: the app being reachable, and this extension being paired with it.
// Once both are true it hands over to the real thing: compact in the toolbar window, full size in a tab.
const root = document.getElementById('app')
const ask = (msg) => chrome.runtime.sendMessage(msg)
const inTab = location.hash === '#tab'
if (inTab) document.body.classList.add('tab')

const h = (tag, props, ...kids) => {
  const el = document.createElement(tag)
  for (const [k, v] of Object.entries(props || {})) { if (k === 'class') el.className = v; else if (k.startsWith('on')) el.addEventListener(k.slice(2), v); else el.setAttribute(k, v) }
  el.append(...kids)
  return el
}
const state = (title, text, ...more) => root.replaceChildren(h('div', { class: 'state' }, h('div', { class: 'brand' }, h('img', { src: 'icons/48.png', alt: '' }), h('b', {}, 'ASTRALA')), h('h1', {}, title), h('p', {}, text), ...more))
const NOTE = 'Your keys stay in the Astrala app. This extension shows your wallet and carries what you do to the app; every payment still needs your PIN.'

const goLocal = () => location.replace(chrome.runtime.getURL('shell.html') + (inTab ? '#tab' : ''))
async function useBrowser() { await chrome.storage.local.set({ mode: 'local' }); goLocal() }
const LOCAL_NOTE = 'Beta. Your keys are stored encrypted in this browser and every payment needs your PIN. Monero, Tor and Mullvad routing, hardware wallets and swaps are only in the Astrala app.'

async function start() {
  if ((await chrome.storage.local.get('mode')).mode === 'local') return goLocal()
  const st = await ask({ type: 'status' }).catch(() => null)
  if (!st || !st.running) return state("Astrala isn't reachable", 'Open the Astrala app, then turn on Settings → Security → Browser extension.', h('button', { class: 'btn main wide', onclick: start }, 'Try again'), h('button', { class: 'btn wide', onclick: useBrowser }, 'Use Astrala in this browser'), h('p', { class: 'note' }, LOCAL_NOTE))
  if (!st.paired) return state('Pair with the app', 'Pairing ties this extension to the Astrala app on this computer. You confirm it in the app.', h('button', { class: 'btn main wide', onclick: pair }, 'Pair with Astrala'), h('p', { class: 'note' }, NOTE), h('button', { class: 'btn wide', onclick: useBrowser }, 'Use this browser on its own'))
  location.replace(chrome.runtime.getURL('app/index.html') + (inTab ? '' : '?popup'))
}
async function pair() {
  const code = String(crypto.getRandomValues(new Uint32Array(1))[0] % 1000000).padStart(6, '0')
  const id = chrome.runtime.id.slice(-8)
  state('Confirm in Astrala', `The app is showing a code and an extension ID. Approve it there only if both match: code below, ID ending ${id}.`, h('div', { class: 'code' }, `${code.slice(0, 3)} ${code.slice(3)}`), h('p', {}, 'Waiting for you in the app…'))
  const r = await ask({ type: 'pair', code }).catch(() => null)
  if (r && r.ok) return start()
  // another request is on screen in the app: it is not this one, so it must be declined there
  if (r && /busy/i.test(r.why || '')) return state('Another request is waiting in Astrala', `The app is showing a pairing request that did not come from this extension. Decline it in the app (its ID won't end ${id}), then try again.`, h('button', { class: 'btn main wide', onclick: pair }, 'Try again'))
  state('Not paired', (r && r.why) || 'Something went wrong.', h('button', { class: 'btn main wide', onclick: pair }, 'Try again'))
}
start()
